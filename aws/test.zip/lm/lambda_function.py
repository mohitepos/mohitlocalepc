import json
import boto3
import pymysql
import requests
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

# Initialize the S3 client
s3_client = boto3.client('s3')

# MySQL database configuration
db_config = {
    host: '172.31.31.51',
    user: 'sml',
    password: 'Quytech@1123',
    database: 'sml_db'
}

def lambda_handler(event, context):
    # Extract parameters from the event
    url = event.get('url')
    bucket_name = event.get('bucketName')
    key = event.get('key')
    db_update_query = event.get('dbUpdateQuery')
    db_update_params = event.get('dbUpdateParams')

    # Initialize the MySQL connection
    connection = pymysql.connect(**db_config)
    
    try:
        # Download the file from the URL
        response = requests.get(url)
        response.raise_for_status()
        file_content = response.content
        
        # Upload the file to S3
        s3_client.put_object(Bucket=bucket_name, Key=key, Body=file_content)
        
        # Update the MySQL table
        with connection.cursor() as cursor:
            cursor.execute(db_update_query, db_update_params)
        connection.commit()
        
        return {
            'statusCode': 200,
            'body': json.dumps('Upload and database update successful')
        }
    
    except requests.exceptions.RequestException as e:
        print(f"Error downloading file: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error downloading file: {e}")
        }
    except (NoCredentialsError, PartialCredentialsError) as e:
        print(f"Error with S3 credentials: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error with S3 credentials: {e}")
        }
    except pymysql.MySQLError as e:
        print(f"Error with MySQL: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error with MySQL: {e}")
        }
    finally:
        connection.close()